//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
