//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

//str =16 tapeqdo seguro

let inge = "guapo"
//inge = "feo" infertencia

/*
 para comentar varias lineas
 tipos de dato:
 String
 Int
 Dlouble: con punto decimal
 Float
 Bool
 */

var edad = 13
print(edad)

var deuda = 19.8
type(of: deuda) //determine el tipo de dato

//en swift estan prohibidos los valores nulos

//operaciones binarias: + - / * %
var x = 10
var y = 23

x + y
//x +y  co los espacios identifica los elementos, por eso espacio entre los operadores, exepto -

x + -y

// no se pueden sumar diferentes tipos de datos, por que tiwnen diferentes espacios de memoria

"hola" + " muchachos" //+ si puede sumar cadenas!! dejar espacios

//nombrado de datos: descriptivos,

//var angleY asi sì
//var a_y asi no

var numeroGrande = 1000000
numeroGrande = 1_000_000 //igual a la de arriba

var 🐱 = "pichirilo"
var perro = "🐶"
print(perro)

//incremento y decremento
var counter = 1
counter += 1
counter -= 1
counter *= 5 //multiplicar
counter /= 5 // dividir



