//: Playground - noun: a place where people can play

import UIKit

var ingeniero = "guapo"
ingeniero = "feo"
type(of: ingeniero)


let ingeniera = "fea"
//ingeniera = "bonita"

/*
 Int
 String
 Double
 Float
 Bool
 */

var edad1 = 10
var edad2 : Int = 10
var edad3 = Int(10.0)
var edad4 = 10 as Int

"pedro" + "jimenez"
var perrito = "🐶"
var vocal = "A"
type(of : vocal)

var name = "Diego"
var message = "Hola mundo yo me llamo \(name) y tengo sueño y tengo \(20) años"
print (message)


var tupla : (x:Int, y:Int, z:int )= (9,8,5)









